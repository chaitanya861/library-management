<!-- 
	// $conn=new mysqli('localhost','root','','library');
	// $fnam=$_POST['fname'];
	// $lname=$_POST['lname'];
	// $id=$_POST['id'];
	// $branch=$_POST['branch'];
	// $email=$_POST['email'];
	// $pass=$_POST['pass'];

	

	// $sqll="insert into register values('$fnam','$lname','$id','$branch','$email','$pass')";
	// $res=$conn->query($sqll); -->


<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css" href="login.css">
<style type="text/css">
	button{
		background-color: green;
	}
	.xd{
            font-family: verdana;
            font-size: 20px;
            //padding-bottom: 5px;
            //padding-top: 5px;
            /*line-height: 20px;*/
        }
</style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>NALANDA &nbsp;&nbsp;LIBRARY</h1><br/><br/>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">
				<nav>
					<ul>
				      <li><a href="student.html" style="text-decoration: none;" >Your Details</a></li>
				      <li><a href="viewbook.html" style="text-decoration: none;">View / Search Book</a></li>
				      <li><a href="#" style="text-decoration: none;">Issue Book</a></li>
				      <li><a href="#" style="text-decoration: none;">recommand Book</a></li>
				      <li><a href="#" style="text-decoration: none;">currently issued Books</a></li>
				    </ul>
				</nav>
			</div>
			<div class="col-md-6">
				<article>
						<div class="r
					<h1 class="lol"> copyright, belongs to Nalanda NITC Library </h1>
				</footer>
			</div>
		</div>
	</div>
</body>
</html>